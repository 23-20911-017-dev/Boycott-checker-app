import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Image,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
} from 'react-native';

// Your Firebase Database URL
const FIREBASE_URL = 'https://boycott-checker-b3d66-default-rtdb.asia-southeast1.firebasedatabase.app';

export default function App() {
  const [screen, setScreen] = useState('splash');
  const [brandInput, setBrandInput] = useState('');
  const [result, setResult] = useState(null);
  const [boycottCategories, setBoycottCategories] = useState({});
  const [loading, setLoading] = useState(true);

  // Fetch data from Firebase when app starts
  useEffect(() => {
    fetchFirebaseData();
  }, []);

  const fetchFirebaseData = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${FIREBASE_URL}/boycottCategories.json`);
      const data = await response.json();
      
      if (data) {
        setBoycottCategories(data);
        console.log('✅ Data loaded from Firebase!');
      }
    } catch (error) {
      console.error('❌ Firebase Error:', error);
      alert('Could not load data from Firebase');
    } finally {
      setLoading(false);
    }
  };

  const checkBrand = () => {
    const input = brandInput.toLowerCase().trim();
    
    if (input === '') {
      setResult({ type: 'warning', message: 'Please enter a brand name.' });
      return;
    }

    // Convert input to match Firebase keys (replace spaces with underscores)
    const searchKey = input.replace(/\s+/g, '_');

    // Search through all categories
    for (let category in boycottCategories) {
      const brands = boycottCategories[category];
      
      // Check exact match
      if (brands[searchKey]) {
        const b = brands[searchKey];
        setResult({
          type: 'boycott',
          brand: b.name,
          desc: b.desc,
          alternative: b.alternative
        });
        return;
      }

      // Also check by brand name (case insensitive)
      for (let key in brands) {
        if (brands[key].name && brands[key].name.toLowerCase() === input) {
          const b = brands[key];
          setResult({
            type: 'boycott',
            brand: b.name,
            desc: b.desc,
            alternative: b.alternative
          });
          return;
        }
      }
    }

    setResult({
      type: 'safe',
      brand: brandInput.trim()
    });
  };

  // Loading Screen
  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" />
        <View style={styles.loadingScreen}>
          <ActivityIndicator size="large" color="#00FF00" />
          <Text style={styles.loadingText}>Loading from Firebase...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // Splash Screen
  if (screen === 'splash') {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" />
        <View style={styles.splashScreen}>
          <Image
            source={{ uri: 'https://flagcdn.com/w320/ps.png' }}
            style={styles.splashBg}
            resizeMode="cover"
          />
          <View style={styles.splashOverlay}>
            <View style={styles.splashBox}>
              <View style={styles.logoCircle}>
                <Text style={styles.logoEmoji}>🚫</Text>
              </View>
              <Text style={styles.splashTitle}>Boycott</Text>
              <Text style={styles.splashTitle}>Checker</Text>
              <Text style={styles.splashSubtitle}>Stand Together for Justice</Text>
              <TouchableOpacity
                style={styles.splashButton}
                onPress={() => setScreen('welcome')}
              >
                <Text style={styles.splashButtonText}>Start</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // Welcome Screen
  if (screen === 'welcome') {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" />
        <View style={styles.welcomeScreen}>
          <Image
            source={{ uri: 'https://flagcdn.com/w320/ps.png' }}
            style={styles.welcomeImage}
            resizeMode="cover"
          />
          <View style={styles.welcomeOverlay}>
            <View style={styles.welcomeBox}>
              <View style={styles.flagsContainer}>
                <Image
                  source={{ uri: 'https://flagcdn.com/w160/pk.png' }}
                  style={styles.flagImage}
                  resizeMode="cover"
                />
                <Image
                  source={{ uri: 'https://flagcdn.com/w160/ps.png' }}
                  style={styles.flagImage}
                  resizeMode="cover"
                />
              </View>
              <Text style={styles.welcomeTitle}>Welcome</Text>
              <Text style={styles.welcomeSubtitle}>
                Say NO to Zionist brands & YES to Pakistani products.
              </Text>
              <TouchableOpacity
                style={styles.continueButton}
                onPress={() => setScreen('home')}
              >
                <Text style={styles.continueButtonText}>Continue</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // Home Screen
  if (screen === 'home') {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" />
        <View style={styles.homeScreen}>
          <Image
            source={{ uri: 'https://flagcdn.com/w320/ps.png' }}
            style={styles.homeScreenBg}
            resizeMode="cover"
          />
          <View style={styles.homeScreenOverlay}>
            <View style={styles.contentBox}>
              <Text style={styles.mainTitle}>🇵🇰 Boycott Checker</Text>
              <Text style={styles.subtitle}>
                Check boycott brands & find Pakistani alternatives.
              </Text>
              
              <TouchableOpacity
                style={styles.homeButton}
                onPress={() => {
                  setScreen('checker');
                  setBrandInput('');
                  setResult(null);
                }}
              >
                <Text style={styles.homeButtonText}>🔍 Check a Brand</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.homeButton}
                onPress={() => setScreen('list')}
              >
                <Text style={styles.homeButtonText}>📃 See Full List</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // Brand Checker Screen
  if (screen === 'checker') {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" />
        <View style={styles.checkerScreen}>
          <Image
            source={{ uri: 'https://flagcdn.com/w320/ps.png' }}
            style={styles.checkerScreenBg}
            resizeMode="cover"
          />
          <View style={styles.checkerScreenOverlay}>
            <ScrollView contentContainerStyle={styles.scrollContent}>
              <View style={styles.contentBox}>
                <Text style={styles.screenTitle}>🔍 Brand Checker</Text>
                
                <TextInput
                  style={styles.input}
                  placeholder="Enter brand name..."
                  placeholderTextColor="#999"
                  value={brandInput}
                  onChangeText={setBrandInput}
                  onSubmitEditing={checkBrand}
                />

                <TouchableOpacity style={styles.checkButton} onPress={checkBrand}>
                  <Text style={styles.checkButtonText}>Check</Text>
                </TouchableOpacity>

                {result && (
                  <View style={styles.resultBox}>
                    {result.type === 'boycott' && (
                      <>
                        <Text style={styles.resultTitle}>❌ {result.brand.toUpperCase()}</Text>
                        <Text style={styles.resultDesc}>{result.desc}</Text>
                        <View style={styles.alternativeBox}>
                          <Text style={styles.alternativeTitle}>✅ Alternative:</Text>
                          <Text style={styles.alternativeText}>{result.alternative}</Text>
                        </View>
                      </>
                    )}
                    {result.type === 'safe' && (
                      <Text style={styles.safeText}>
                        ✅ <Text style={styles.safeBrand}>{result.brand.toUpperCase()}</Text> is safe (not in boycott list).
                      </Text>
                    )}
                    {result.type === 'warning' && (
                      <Text style={styles.warningText}>⚠️ {result.message}</Text>
                    )}
                  </View>
                )}

                <TouchableOpacity
                  style={styles.backButton}
                  onPress={() => setScreen('home')}
                >
                  <Text style={styles.backButtonText}>⬅ Back</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // List Screen
  if (screen === 'list') {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" />
        <View style={styles.listScreen}>
          <Image
            source={{ uri: 'https://flagcdn.com/w320/ps.png' }}
            style={styles.listScreenBg}
            resizeMode="cover"
          />
          <View style={styles.listScreenOverlay}>
            <Text style={styles.listTitle}>🚫 Boycott Brands & ✅ Alternatives</Text>
            
            <ScrollView style={styles.listScroll} contentContainerStyle={styles.listContent}>
              {Object.keys(boycottCategories).map((category, idx) => (
                <View key={idx} style={styles.categoryBox}>
                  <Text style={styles.categoryTitle}>{category.replace(/_/g, ' ')}</Text>
                  
                  <View style={styles.table}>
                    <View style={styles.tableHeader}>
                      <Text style={[styles.tableHeaderText, styles.col1]}>Brand</Text>
                      <Text style={[styles.tableHeaderText, styles.col2]}>Description</Text>
                      <Text style={[styles.tableHeaderText, styles.col3]}>Alternative</Text>
                    </View>

                    {Object.keys(boycottCategories[category]).map((brandKey, i) => {
                      const b = boycottCategories[category][brandKey];
                      return (
                        <View key={i} style={[styles.tableRow, i % 2 === 0 && styles.tableRowEven]}>
                          <Text style={[styles.tableCell, styles.col1]}>{b.name.toUpperCase()}</Text>
                          <Text style={[styles.tableCell, styles.col2]}>{b.desc}</Text>
                          <Text style={[styles.tableCell, styles.col3]}>{b.alternative}</Text>
                        </View>
                      );
                    })}
                  </View>
                </View>
              ))}

              <TouchableOpacity
                style={styles.backButton}
                onPress={() => setScreen('home')}
              >
                <Text style={styles.backButtonText}>⬅ Back</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  return null;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  loadingScreen: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 16,
    marginTop: 20,
  },
  splashScreen: {
    flex: 1,
    position: 'relative',
  },
  splashBg: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  splashOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  splashBox: {
    alignItems: 'center',
    padding: 40,
  },
  logoCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#1a1a1a',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 3,
    borderColor: '#00FF00',
    shadowColor: '#00FF00',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 15,
  },
  logoEmoji: {
    fontSize: 45,
  },
  splashTitle: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  splashSubtitle: {
    fontSize: 14,
    color: '#CCCCCC',
    marginTop: 10,
    marginBottom: 35,
    textAlign: 'center',
  },
  splashButton: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 15,
    paddingHorizontal: 50,
    borderRadius: 25,
  },
  splashButtonText: {
    color: '#000',
    fontSize: 20,
    fontWeight: 'bold',
  },
  welcomeScreen: {
    flex: 1,
    position: 'relative',
  },
  welcomeImage: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  welcomeOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  welcomeBox: {
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    padding: 40,
    borderRadius: 20,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#006400',
  },
  flagsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    gap: 15,
  },
  flagImage: {
    width: 80,
    height: 60,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  welcomeTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 15,
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 24,
  },
  continueButton: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 25,
  },
  continueButtonText: {
    color: '#006400',
    fontSize: 18,
    fontWeight: 'bold',
  },
  homeScreen: {
    flex: 1,
    position: 'relative',
  },
  homeScreenBg: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  homeScreenOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 100, 0, 0.75)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  contentBox: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    padding: 30,
    borderRadius: 20,
    width: '100%',
    maxWidth: 400,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  mainTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 30,
  },
  homeButton: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 12,
    marginVertical: 8,
  },
  homeButtonText: {
    color: '#006400',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  checkerScreen: {
    flex: 1,
    position: 'relative',
  },
  checkerScreenBg: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  checkerScreenOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 51, 102, 0.75)',
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  screenTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 10,
    fontSize: 16,
    marginBottom: 15,
    color: '#000',
  },
  checkButton: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  checkButtonText: {
    color: '#003366',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  resultBox: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    padding: 20,
    borderRadius: 15,
    marginBottom: 20,
  },
  resultTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#CC0000',
    marginBottom: 10,
  },
  resultDesc: {
    fontSize: 16,
    color: '#000',
    marginBottom: 15,
  },
  alternativeBox: {
    backgroundColor: '#E8F5E9',
    padding: 15,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#006400',
  },
  alternativeTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#006400',
    marginBottom: 5,
  },
  alternativeText: {
    fontSize: 18,
    color: '#000',
    fontWeight: 'bold',
  },
  safeText: {
    fontSize: 18,
    color: '#006400',
    textAlign: 'center',
  },
  safeBrand: {
    fontWeight: 'bold',
  },
  warningText: {
    fontSize: 16,
    color: '#FF6600',
    textAlign: 'center',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
  },
  backButtonText: {
    color: '#003366',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  listScreen: {
    flex: 1,
    position: 'relative',
  },
  listScreenBg: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  listScreenOverlay: {
    flex: 1,
    backgroundColor: 'rgba(102, 0, 51, 0.75)',
  },
  listTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    padding: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
  },
  listScroll: {
    flex: 1,
  },
  listContent: {
    padding: 15,
    paddingBottom: 30,
  },
  categoryBox: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    padding: 15,
    borderRadius: 15,
    marginBottom: 20,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  categoryTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFD700',
    marginBottom: 15,
  },
  table: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    overflow: 'hidden',
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#006400',
    padding: 12,
  },
  tableHeaderText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
  tableRow: {
    flexDirection: 'row',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  tableRowEven: {
    backgroundColor: '#F5F5F5',
  },
  tableCell: {
    fontSize: 12,
    color: '#000',
  },
  col1: {
    flex: 2,
  },
  col2: {
    flex: 3,
  },
  col3: {
    flex: 2,
  },
});